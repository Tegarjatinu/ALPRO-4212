#include <iostream>

using namespace std;

void bubble_sort(int arr[], int n){
    for(int i=0; i<n; i++){
        for(int j=0; j<n-i-1; j++){
            if(arr[j] < arr[j+1]){
                swap(arr[j], arr[j+1]);
            }
        }
    }
}

void insertion_sort(int arr[], int n){
    int i,j,key;
    for(int i=1; i<n; i++){
        key=arr[i];
        j = i-1;
        for(int j=i-1; j>=0 && arr[j] < key ;j--){
            arr[j+1]=arr[j];
        }
        arr[j+1]=key;
    }
}
void print(int arr[], int n){
cout << "Hasil sorting: ";
for(int i=0; i<n; i++){
    cout << arr[i] << " ";
}cout << endl;
}
int main()
{
    int arr[] = {5,4,3,2,2,1,1};
    int n = sizeof(arr)/sizeof(arr[0]);
    bubble_sort(arr,n);
    cout << "Bubble Sort: " << endl;
    print(arr,n);

    int arr2[] = {5,4,3,2,2,1,1};
    int n2 = sizeof(arr2)/sizeof(arr2[0]);

    insertion_sort(arr2,n2);
    cout << "insertion Sort: " << endl;
    print(arr2,n2);
    return 0;
}
